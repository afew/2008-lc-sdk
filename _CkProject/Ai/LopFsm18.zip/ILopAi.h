// Interface for the ILopAi class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILopAi_H_
#define _ILopAi_H_

#pragma warning(disable: 4786)

#include <list>
#include <map>
#include <string>

using namespace std;


namespace	ILopAi
{

enum EocState
{
	OCST_NONE,
	OCST_IDLE,
	OCST_WALK,
	OCST_RUN,
	OCST_DASH,
	OCST_ATTACK,
	OCST_DAMAGE
};

class _Tentity
{
protected:
	INT		m_nID;
	void*	m_pFSM;

public:
	_Tentity();
	virtual ~_Tentity();

	virtual	INT		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	INT		Update();
	virtual	INT		QueryState(char* sCmd, void* pData);
	virtual	INT		QueryValue(char* sCmd, void* pData);

	INT		OnMessage(char* sMsg, void* pMessage);
	INT		GetID();
	void	SetID(INT nID);
};


enum EocValue
{
	MAX_MSG_VALUE	= 64,
	CMD_ONCE		= 0,
	CMD_LOOP		= 1,
};


struct	_Tmessage
{
	INT		CmdType;			// 0: 1���� ����, 1: Loop Command
	void*	Sender;				// Message ������
	char	Value[ILopAi::MAX_MSG_VALUE];
	void*	Extra;				// Extra data exceed Value
	float	Delay;				// Delay Time: 0 is No delay
	DWORD	TimeBgn;			// Sending Time

	_Tmessage();

	_Tmessage(char* sMsg
			, INT nType=0
			, void* Sender=NULL
			, float fDelay =0.f);	// 64Byte �̳� ������

	_Tmessage(void* pMsg
			, INT nSize
			, INT nType=0
			, void* Sender=NULL
			, float fDelay =0.f);	// 64Byte �ʰ� ������

	const _Tmessage& operator=(const _Tmessage& r);	// r: right hand side(rhs)
	const _Tmessage& operator=(const _Tmessage* r);	// r: right hand side(rhs)
};



struct _Tstate
{
	virtual INT	Enter(_Tentity* pEntity)=0;				// Enter State
	virtual INT	Exit(_Tentity* pEntity)=0;				// Exit State
	virtual INT	Exec(_Tentity* pEntity)=0;				// Excute State

	virtual const char*	 const GetName() const =0;		// Get State Name
};


typedef	std::map<std::string, _Tstate*	>	mpTstate;
typedef	mpTstate::iterator					itTstate;


typedef	std::list<_Tmessage >				lsTmessage;
typedef	lsTmessage::iterator				itTmessage;


class _TstateFSM
{
protected:
	_Tentity*	m_pEntity;

	_Tstate*	m_pStCur;	// Current State
	_Tstate*	m_pStOld;	// Old State
	_Tstate*	m_pStInt;	// Interrupt State

	lsTmessage	m_pStEvt;	// Event State List

public:
	_TstateFSM();
	virtual ~_TstateFSM();

	INT			Create(_Tentity* pEntity);
	INT			Update();

	INT			OnMessage(char* sMsg, _Tmessage* pMessage);

	_Tstate*	GetStateCur();
	_Tstate*	GetStateOld();
	_Tstate*	GetStateInt();
};



INT			Lop_StateListCreate(char* []);
void		Lop_StateListDestroy();
mpTstate*	Lop_GetStateList();

}//name space ILopAi


#endif

