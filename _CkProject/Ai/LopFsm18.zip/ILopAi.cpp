// Implementation of the _TstateFSM class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>
#include <mmsystem.h>

#include "ILopAi.h"


////////////////////////////////////////////////////////////////////////////////
namespace ILopAi
{

_Tentity::_Tentity()
{
	m_nID	= 0xFFFFFFFF;
	m_pFSM	= NULL;
}


_Tentity::~_Tentity()
{
}


INT _Tentity::Create(void* p1, void*, void*, void*)
{
	INT nId = (INT)p1;
	SetID(nId);

	return 0;
}

void _Tentity::Destroy()
{
}


INT _Tentity::Update()
{
	return 0;
}


INT _Tentity::QueryState(char* sCmd, void* pData)
{
	return 0;
}


INT _Tentity::QueryValue(char* sCmd, void* pData)
{
	if(0 ==_stricmp(sCmd, "Get ID"))
	{
		*((INT*)pData)	= m_nID;
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Set ID"))
	{
		m_nID = *((INT*)pData);
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Get FSM"))
	{
		*((void**)pData)	= m_pFSM;
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Set FSM"))
	{
		m_pFSM = *((void**)pData);
		return 0;
	}

	return -1;
}

INT _Tentity::OnMessage(char* sMsg, void* pMessage)
{
	_TstateFSM*	pFSM = (_TstateFSM*)m_pFSM;
	return pFSM->OnMessage(sMsg, (_Tmessage*)pMessage);
}


void _Tentity::SetID(INT nID)
{
	m_nID	= nID;
}


INT _Tentity::GetID()
{
	return m_nID;
}



////////////////////////////////////////////////////////////////////////////////

struct _TstateBase : public _Tstate
{
	char	sName[64];

	_TstateBase()
	{
		memset(sName, 0, sizeof sName);
	}

	_TstateBase(const char* _sName)
	{
		memset(sName, 0, sizeof sName);
		strcpy(sName, _sName);
	}

	virtual const char*	 const GetName() const
	{
		return sName;
	}

	void SetName(char* _sName)
	{
		strcpy(sName, _sName);
	}


	virtual INT	Enter(_Tentity* pEntity);				// Enter State
	virtual INT	Exit(_Tentity* pEntity);				// Exit State
	virtual INT	Exec(_Tentity* pEntity);				// Excute State
};


INT	_TstateBase::Enter(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Enter %s", sName);
	return pEntity->QueryState(sCmd, NULL);
}

INT	_TstateBase::Exit(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Exit %s", sName);
	return pEntity->QueryState(sCmd, NULL);
}

INT	_TstateBase::Exec(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Exec %s", sName);
	return pEntity->QueryState(sCmd, NULL);
}



////////////////////////////////////////////////////////////////////////////////
_Tmessage::_Tmessage()
{
	CmdType		= 0;
	Sender		= NULL;
	Extra		= NULL;
	Delay		= 0;
	TimeBgn		= 0;

	memset(Value, 0, ILopAi::MAX_MSG_VALUE);
}


// 64Byte �̳� ������
_Tmessage::_Tmessage(char* sMsg, INT nType, void* pSender, float fDelay)
{
	CmdType		= nType;
	Sender		= pSender;
	Extra		= NULL;
	Delay		= fDelay;
	TimeBgn		= ::timeGetTime();

	memcpy(Value, sMsg, ILopAi::MAX_MSG_VALUE);
}

// 64Byte �ʰ� ������
_Tmessage::_Tmessage(void* pMsg, INT nSize, INT nType, void* pSender, float fDelay)
{
	CmdType		= nType;
	Sender		= pSender;
	Extra		= pMsg;
	Delay		= fDelay;
	TimeBgn		= ::timeGetTime();

	memset(Value, 0, ILopAi::MAX_MSG_VALUE);
	memcpy(Value, &nSize, sizeof(INT));
}



const _Tmessage& _Tmessage::operator=(const _Tmessage& r)	// r: right hand side(rhs)
{	
	CmdType		= r.CmdType;
	Sender		= r.Sender;
	Extra		= r.Extra;
	Delay		= r.Delay;
	TimeBgn		= r.TimeBgn;

	memcpy(Value, r.Value, ILopAi::MAX_MSG_VALUE);

	return *this;
}

const _Tmessage& _Tmessage::operator=(const _Tmessage* r)	// r: right hand side(rhs)
{	
	CmdType		= r->CmdType;
	Sender		= r->Sender;
	Extra		= r->Extra;
	Delay		= r->Delay;
	TimeBgn		= r->TimeBgn;

	memcpy(Value, r->Value, ILopAi::MAX_MSG_VALUE);

	return *this;
}


////////////////////////////////////////////////////////////////////////////////
_TstateFSM::_TstateFSM() : m_pStEvt(0)
{
	m_pStCur	= NULL;
	m_pStOld	= NULL;
	m_pStInt	= NULL;
}

_TstateFSM::~_TstateFSM()
{
	m_pStEvt.clear();
}


INT _TstateFSM::Create(_Tentity* pEntity)
{
	m_pEntity	= pEntity;

	_Tmessage pMessage("Idle");
	this->OnMessage("Change State", &pMessage);

	return 0;
}


INT _TstateFSM::Update()
{
	DWORD	dCur = ::timeGetTime();

	if(!m_pStEvt.empty())
	{
		itTmessage	_F	= m_pStEvt.begin();
		itTmessage	_L	= m_pStEvt.end();

		for(; _F != _L; ++_F)
		{
			FLOAT	Delay = (*_F).Delay;
			(*_F).Delay = Delay -(dCur - (*_F).TimeBgn);
			(*_F).TimeBgn = dCur;
		}

		_F	= m_pStEvt.begin();

		if( (*_F).Delay<=0.f)
		{
			(*_F).Delay = 0;
			_Tmessage t = (*_F);

			this->OnMessage("Change State", &t);
			m_pStEvt.erase(_F);
		}
	}

	if(m_pStInt)
	{
		m_pStInt->Exec(m_pEntity);
		return 0;
	}

	if(m_pStCur)
		m_pStCur->Exec(m_pEntity);

	return 0;
}


INT _TstateFSM::OnMessage(char* sMsg, _Tmessage* pMessage)
{
	if(0==_stricmp("Change State", sMsg))
	{
		mpTstate*	pSt = Lop_GetStateList();
		itTstate	it	= pSt->find(pMessage->Value);

		if( it == pSt->end())
			return -1;

		// Delay�� ���� ��� �ٷ� ����
		if(0 >= pMessage->Delay)
		{
			if(m_pStCur)
				m_pStCur->Exit(m_pEntity);

			m_pStOld	= m_pStCur;

			m_pStCur = (*it).second;
			m_pStCur->Enter(m_pEntity);
		}

		// �켱 ���� ť�� �ִ´�.
		else
		{
			_Tmessage	t	= *pMessage;
			itTmessage	_F	= m_pStEvt.begin();
			itTmessage	_L	= m_pStEvt.end();

			for(; _F != _L; ++_F)
			{
				if(t.Delay< (*_F).Delay)
					break;
			}

			m_pStEvt.insert(_F, t);
		}

		return 0;
	}


	return -1;
}

_Tstate* _TstateFSM::GetStateCur()	{	return m_pStCur;	}
_Tstate* _TstateFSM::GetStateOld()	{	return m_pStOld;	}
_Tstate* _TstateFSM::GetStateInt()	{	return m_pStInt;	}




////////////////////////////////////////////////////////////////////////////////

static mpTstate*	g_lsLopState	= NULL;

INT Lop_StateListCreate(char* argv[])
{
	if(g_lsLopState)
		return 0;

	g_lsLopState	= new mpTstate;

	for(INT i=0; argv[i]; ++i)
	{
		_Tstate* p = new _TstateBase(argv[i]	);
		g_lsLopState->insert(mpTstate::value_type(argv[i], p));
	}
	
	return 0;
}


void Lop_StateListDestroy()
{
	if(g_lsLopState)
	{
		itTstate	_F	= g_lsLopState->begin();
		itTstate	_L	= g_lsLopState->end();

		for( ; _F != _L; ++_F)
			delete (*_F).second;

		g_lsLopState->clear();

		delete g_lsLopState;
		g_lsLopState	= NULL;
	}
}


mpTstate* Lop_GetStateList()
{
	return g_lsLopState;
}


}// namespace ILopAi