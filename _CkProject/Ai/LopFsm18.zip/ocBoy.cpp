// Implementation of the TocBoy class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>
#include <d3dx9.h>

#include "ILopAi.h"
#include "ocAmun.h"
#include "ocBoy.h"


INT TocBoy::Create(void* p1,void* p2,void* p3,void* p4)
{
	if(FAILED(TocAmun::Create(p1, p2, p3, p4)))
		return -1;

	this->QueryState("Set Stamina", (void*)5);

	ILopAi::_TstateFSM* pFSM	= new ILopAi::_TstateFSM;

	pFSM->Create(this);
	m_pFSM = pFSM;

	return 0;
}

void TocBoy::Destroy()
{
	if(m_pFSM)
	{
		delete m_pFSM;
		m_pFSM = NULL;
	}
}

INT TocBoy::Update()
{
	ILopAi::_TstateFSM*	pFSM = (ILopAi::_TstateFSM*)m_pFSM;

	if(FAILED(pFSM->Update()))
		return -1;

	return 0;
}


INT TocBoy::QueryState(char* sCmd, void* pData)
{
	INT nId	= this->GetID();

	if(0 ==_stricmp(sCmd, "Enter Attack"))
	{
		printf("(%4d): Enter Attack \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exit Attack"))
	{
		printf("(%4d): Exit Attack \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exec Attack"))
	{
		printf("(%4d): Exec Attack \n", nId );
		return 0;
	}


	if(0 ==_stricmp(sCmd, "Enter Damage"))
	{
		printf("(%4d): Enter Damage \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exit Damage"))
	{
		printf("(%4d): Exit Damage \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exec Damage"))
	{
		printf("(%4d): Exec Damage \n", nId );
		return 0;
	}

	else
	{
		if(FAILED(TocAmun::QueryState(sCmd, pData)))
			return -1;
	}

	return -1;
}



