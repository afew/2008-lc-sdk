// Interface for the TocBoy class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _TocBoy_H_
#define _TocBoy_H_


class TocBoy : public TocAmun
{
protected:

public:

	TocBoy();
	virtual ~TocBoy();

	virtual	INT		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	INT		Update();
	virtual	INT		QueryState(char* sCmd, void* pData);	
};


#endif

