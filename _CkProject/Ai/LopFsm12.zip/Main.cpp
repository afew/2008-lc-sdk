

#include <windows.h> 
#include <stdio.h>

#include "ILopAi.h"
#include "Miner.h"


void main()
{
	if(FAILED(ILopAi::Lop_StateListCreate()))
		return;

	TcharAmun*	pEnt1 = new TcharAmun;
	TcharAmun*	pEnt2 = new TcharAmun;

	pEnt1->Create((void*)10, (void*)1);
	pEnt2->Create((void*)20, (void*)3);

	static int c=0;


	while(1)
	{
		Sleep(100);

		if(++c>50)
			break;

		if(FAILED(pEnt1->Update()))
			break;

		if(FAILED(pEnt2->Update()))
			break;
	}

	pEnt1->Destroy();
	delete pEnt1;


	pEnt2->Destroy();
	delete pEnt2;


	ILopAi::Lop_StateListDestroy();
}