// Implementation of the CMiner class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>

#include "ILopAi.h"
#include "Miner.h"


int TcharAmun::Create(void* p1,void* p2,void* p3,void* p4)
{
	int nId = (int)p1;
	SetID(nId);

	int iThist = (int)p2;
	m_iThirst	= iThist;

	this->QueryState("Set Stamina", (void*)5);

	ILopAi::_TstateMachine* pFSM	= new ILopAi::_TstateMachine;

	pFSM->Create(this);
	m_pFSM = pFSM;

	return 0;
}

void TcharAmun::Destroy()
{
	if(m_pFSM)
	{
		delete m_pFSM;
		m_pFSM = NULL;
	}
}

int TcharAmun::Update()
{
	ILopAi::_TstateMachine*	pFSM = (ILopAi::_TstateMachine*)m_pFSM;

	m_iThirst += 1;
  
	if(FAILED(pFSM->Update()))
		return -1;

	return 0;
}


int TcharAmun::QueryState(char* sCmd, void* pData)
{
	int nId	= this->GetID();

	if(0 ==_stricmp(sCmd, "Exit Mine"))
	{
		printf("(%4d): ��Ah m leavin�� the gold mine with mah pockets full oh sweet gold\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Mine"))
	{
		this->AddToGoldCarried(1);
		this->IncreaseFatigue();

		printf("(%4d): ��Pickin�� up a nugget\n", nId );

		if(this->PocketsFull())
		{
			ILopAi::_Tmessage pMessage(NULL, NULL, "Bank");
			this->OnMessage("Change State", &pMessage);
		}

		if(this->Thirsty())
		{
			ILopAi::_Tmessage pMessage(NULL, NULL, "Saloon");
			this->OnMessage("Change State", &pMessage);
		}

		return 0;
	}


	else if(0 ==_stricmp(sCmd, "Enter Bank"))
	{
		if (this->Location() != bank)
		{
			printf("(%4d): ��Goin' to the bank. Yes siree�� \n", nId );
			this->ChangeLocation(bank);
		}
		
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit Bank"))
	{
		printf("(%4d): Leavin' the bank\n", nId);
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Bank"))
	{
		//deposit the gold
		this->AddToWealth(this->GoldCarried());
		this->SetGoldCarried(0);

		printf("(%4d): Depositing gold. Total savings now: %d \n", nId, this->Wealth() );


		//wealthy enough to have a well earned rest?
		if (this->Wealth() >= ComfortLevel)
		{
			printf("(%4d): WooHoo! Rich enough for now. Back home to mah li'lle lady\n", nId);

			ILopAi::_Tmessage pMessage(NULL, NULL, "Home");
			this->OnMessage("Change State", &pMessage);
		}

		//otherwise get more gold
		else 
		{
			ILopAi::_Tmessage pMessage(NULL, NULL, "Mine");
			this->OnMessage("Change State", &pMessage);
		}

		return 0;
	}

	else if( 0 ==_stricmp(sCmd, "Enter Home"))
	{
		if (this->Location() != shack)
		{
			printf("(%4d): Walkin' home\n", nId);
			this->ChangeLocation(shack);
		}

		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit Home"))
	{
		printf("(%4d): Exit to Home\n", nId);
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Home"))
	{
		if (!this->Fatigued())
		{
			printf("(%4d): All mah fatigue has drained away. Time to find more gold! \n", nId);

			ILopAi::_Tmessage pMessage(NULL, NULL, "Mine");
			this->OnMessage("Change State", &pMessage);
		}

		else 
		{
			//sleep
			this->DecreaseFatigue();
			printf("(%4d): ZZZZ...  \n", nId);
		}

		return 0;
	}


	else if( 0 ==_stricmp(sCmd, "Enter Saloon"))
	{
		if (this->Location() != saloon)
		{    
			this->ChangeLocation(saloon);
			printf("(%4d): Boy, ah sure is thusty! Walking to the saloon \n", nId);
		}

		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit Saloon"))
	{
		printf("(%4d):Leaving the saloon, feelin' good \n", nId);
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Saloon"))
	{
		this->BuyAndDrinkAWhiskey();
		printf("(%4d): That's mighty fine sippin' liquer \n", nId);

		ILopAi::_Tmessage pMessage(NULL, NULL, "Mine");
		this->OnMessage("Change State", &pMessage);

		return 0;
	}


	return -1;
}



void TcharAmun::AddToGoldCarried(const int val)
{
  m_iGoldCarried += val;

  if (m_iGoldCarried < 0) m_iGoldCarried = 0;
}

void TcharAmun::AddToWealth(const int val)
{
  m_iMoneyInBank += val;

  if (m_iMoneyInBank < 0) m_iMoneyInBank = 0;
}

bool TcharAmun::Thirsty()const
{
  if (m_iThirst >= ThirstLevel){return true;}

  return false;
}

bool TcharAmun::Fatigued()const
{
  if (m_iFatigue > TirednessThreshold)
  {
    return true;
  }

  return false;
}