// Interface for the TocBoy class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ocBoy_H_
#define _ocBoy_H_


class TocBoy : public TocAmun
{
protected:
	ILopAi::EocState	m_eSt;

public:

	TocBoy()
	{
		m_eSt		= ILopAi::OCST_IDLE;
	}

	virtual	INT		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	INT		Update();
	virtual	INT		QueryState(char* sCmd, void* pData);

	ILopAi::EocState	GetState()	const	{	return m_eSt;}
};


#endif

