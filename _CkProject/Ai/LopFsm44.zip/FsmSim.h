// Interface for the CFsmSim class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _FsmSim_H_
#define _FsmSim_H_

typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;

typedef LPDIRECT3DDEVICE9				PDEV;

class CFsmSim
{
public:
	struct VtxNUV1
	{
		VEC3	p;
		VEC3	n;
		FLOAT	u, v;

		VtxNUV1()						: p(0,0,0),u(0),v(0){}
		VtxNUV1( FLOAT X, FLOAT Y, FLOAT Z
				, FLOAT x, FLOAT y, FLOAT z
				, FLOAT U, FLOAT V)	: p(X,Y,Z),n(x,y,z),u(U),v(V){}

		enum {	FVF= (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)	};
	};


public:
	PDEV		m_pDev;				// Device

	D3DMATERIAL9	m_Mtl;
	D3DLIGHT9		m_Lgt[3];
	LPD3DXMESH		m_pMesh;			// ������ �޽�

	TocAmun*		m_pAmun;

public:
	CFsmSim();
	virtual ~CFsmSim();

	INT		Create(PDEV pDev);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Restore();
	void	Invalidate();
};

#endif

