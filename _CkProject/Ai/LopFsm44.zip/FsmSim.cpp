// Implementation of the CFsmSim class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CFsmSim::CFsmSim()
{
	m_pDev		= NULL;

	m_pMesh		= NULL;

	m_pAmun		= NULL;
}


CFsmSim::~CFsmSim()
{
	Destroy();
}


INT CFsmSim::Create(PDEV pDev)
{
	HRESULT	hr=0;

	m_pDev = pDev;

	D3DXCreateTorus(m_pDev, 2.f, 4.0f, 40, 40, &m_pMesh, 0);


	memset(m_Lgt, 0, sizeof(D3DLIGHT9) * 3);

	m_Lgt[0].Type      = D3DLIGHT_DIRECTIONAL;
	m_Lgt[0].Ambient   = D3DXCOLOR(1, 0, 0, 1)*0.1f;
	m_Lgt[0].Diffuse   = D3DXCOLOR(1, 0, 0, 1);
	m_Lgt[0].Specular  = D3DXCOLOR(1, 0, 0, 1)*0.3f;
	D3DXVec3Normalize((D3DXVECTOR3*)&m_Lgt[0].Direction, &D3DXVECTOR3( 1, 0.3f, 1));
	m_Lgt[0].Range	   = 10000.f;

	m_Lgt[1].Type      = D3DLIGHT_DIRECTIONAL;
	m_Lgt[1].Ambient   = D3DXCOLOR(0, 1, 0, 1)*0.1f;
	m_Lgt[1].Diffuse   = D3DXCOLOR(0, 1, 0, 1);
	m_Lgt[1].Specular  = D3DXCOLOR(0, 1, 0, 1);
	D3DXVec3Normalize((D3DXVECTOR3*)&m_Lgt[1].Direction, &D3DXVECTOR3(-1, 0.3f, 1));
	m_Lgt[1].Range	   = 10000.f;

	m_Lgt[2].Type      = D3DLIGHT_DIRECTIONAL;
	m_Lgt[2].Ambient   = D3DXCOLOR(1, 0, 1, 1)*0.1f;
	m_Lgt[2].Diffuse   = D3DXCOLOR(1, 0, 1, 1);
	m_Lgt[2].Specular  = D3DXCOLOR(1, 0, 1, 1)*0.3f;
	D3DXVec3Normalize((D3DXVECTOR3*)&m_Lgt[2].Direction, &D3DXVECTOR3(0,0.3f, -1));
	m_Lgt[2].Range	   = 10000.f;



	D3DXCOLOR	dcMtl(1,1,1, 1);
	memset(&m_Mtl, 0, sizeof(D3DMATERIAL9));
	m_Mtl.Ambient  = dcMtl*0.1f;
	m_Mtl.Diffuse  = dcMtl;
	m_Mtl.Specular = dcMtl*0.3f;
	m_Mtl.Emissive = D3DXCOLOR(0,0,0,0);
	m_Mtl.Power    = 20.f;


	INT	nId = 20;

	m_pAmun	= new TocAmun;
	m_pAmun->Create((void*)nId, (void*)3);


	INT Thp	= 10;
	INT Tmp	= 20;
	INT Tst	= 10;
	INT stThreshold	= 20;

	D3DXVECTOR3 vcS	= D3DXVECTOR3(2, 3, 6);
	D3DXVECTOR3 vcB	= D3DXVECTOR3(3, 1, 2);
	D3DXVECTOR3 vcE	= D3DXVECTOR3(300, 0, 10);
	D3DXVECTOR3 vcD	= vcE - vcB;
	D3DXVec3Normalize(&vcD, &vcD);

	stThreshold	*=0.6f;
	vcD	= vcE - vcB;
	D3DXVec3Normalize(&vcD, &vcD);

	m_pAmun->QueryValue("Set Speed", &vcS);
	m_pAmun->QueryValue("Set Position", &vcB);
	m_pAmun->QueryValue("Set Direction", &vcD);
	m_pAmun->QueryValue("Set Target", &vcE);

	m_pAmun->QueryValue("Set Hp", &Thp);
	m_pAmun->QueryValue("Set Mp", &Tmp);
	m_pAmun->QueryValue("Set Stamina", &Tst);
	m_pAmun->QueryValue("Set St Threshold", &stThreshold);

	{
		ILopAi::_Tmessage pMessage(OCSST_ATTACK, NULL, 0, ILopAi::CMD_ONCE, NULL, 100);
		m_pAmun->OnMessage("Change State", &pMessage);
	}
	{
		ILopAi::_Tmessage pMessage(OCSST_DAMAGE, NULL, 0, ILopAi::CMD_ONCE, NULL, 200);
		m_pAmun->OnMessage("Change State", &pMessage);
	}
	{
		ILopAi::_Tmessage pMessage(OCSST_RUN, NULL, 0, ILopAi::CMD_LOOP, NULL, 300);
		m_pAmun->OnMessage("Change State", &pMessage);
	}


	return 0;
}

void CFsmSim::Destroy()
{
	SAFE_RELEASE(	m_pMesh		);
	
	m_pAmun->Destroy();

	SAFE_DELETE(	m_pAmun	);
}


INT CFsmSim::FrameMove()
{
	D3DXVECTOR3 vcS	= D3DXVECTOR3(1, 4, 6);
	vcS *=0.1f;
	vcS	*= g_pApp->GetElapsedTime();
	
	m_pAmun->QueryValue("Set Speed", &vcS);

	m_pAmun->UpdateFSM();
	
	return 0;
}


INT CFsmSim::Restore()
{
	return 0;
}

void CFsmSim::Invalidate()
{
}


void CFsmSim::Render()
{
	for(int i=0; i<8; ++i)
	{
		m_pDev->SetSamplerState(i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
		m_pDev->SetSamplerState(i, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	}


	for(i=0; i<8; ++i)
		m_pDev->LightEnable(i, FALSE);


	D3DXVECTOR3 vcDir(1.0f, -0.0f, 0.25f);


	// ����̽��� ������ ����
	m_pDev->SetLight(0, &m_Lgt[0]);	m_pDev->LightEnable(0, TRUE);
	m_pDev->SetLight(1, &m_Lgt[1]);	m_pDev->LightEnable(1, TRUE);
	m_pDev->SetLight(2, &m_Lgt[2]);	m_pDev->LightEnable(2, TRUE);


	// ����̽��� ������ ���� ����
	m_pDev->SetRenderState(D3DRS_LIGHTING, TRUE);
	m_pDev->SetRenderState(D3DRS_NORMALIZENORMALS, TRUE);
	m_pDev->SetRenderState(D3DRS_SPECULARENABLE, TRUE);
	
	m_pDev->SetMaterial(&m_Mtl);

	D3DXMATRIX	mtWld;
	D3DXVECTOR3	vcPos(0,0,0);

	D3DXMatrixIdentity(&mtWld);
	m_pAmun->QueryValue("Get Position", &vcPos);
	mtWld._41 = vcPos.x;
	mtWld._42 = vcPos.y;
	mtWld._43 = vcPos.z;

	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);
	m_pMesh->DrawSubset( 0 );

	D3DXMatrixIdentity(&mtWld);
	m_pDev->SetTransform(D3DTS_WORLD, &mtWld);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetTexture(0, NULL);
}



