// Interface for the ILopAi.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILopAi_H_
#define _ILopAi_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif



struct _TLopState
{
	char	sState[32];			// State Type or State Name
	char	sValue[128];		// Value
	void*	pExtra;				// Extra Data
	void*	pOwner;				// State Owner

	_TLopState();
	_TLopState(void* _pOwner, char* _sState, char* _sValue, int _nValueSize=0, void* _pData=0);

	void	SetState(void* _pOwner, char* _sState, char* _sValue, int _nValueSize=0, void* _pData=0);

	virtual INT	Enter()=0;
	virtual INT	Leave()=0;
	virtual INT	Exec()=0;
};


struct	_TLopMsg
{
	void*	pSender;			//the entity that sent this telegram
	char	sValue[128];
	void*	pExtra;				// Extra data exceed sValue
	float	fDelay;				// Dispatch Time: 0 is No delay

	_TLopMsg()
	{
		pSender		= NULL;

		pExtra		= NULL;
		fDelay		= NULL;

		memset(sValue, 0, sizeof(sValue));
	}


	_TLopMsg(void*	_pSender, void*	_pReceiver, char* _sMsg, float _fDelay =0.f, void* _pExtra = NULL)
	{
		pSender		= _pSender;
		fDelay		= _fDelay;
		pExtra		= _pExtra;

		memcpy(sValue, _sMsg, sizeof(sValue));
	}

};



interface ILopAi
{
	LC_CLASS_DESTROYER(	ILopAi	);

	
	virtual	INT		SetStateCur(_TLopState* sState)=0;
	virtual	INT		SetStateOld(_TLopState* sState)=0;
	virtual	INT		SetStateInt(_TLopState* sState)=0;

	virtual	INT		GetStateCur(_TLopState** sState)=0;
	virtual	INT		GetStateOld(_TLopState** sState)=0;
	virtual	INT		GetStateInt(_TLopState** sState)=0;

	virtual	INT		CompareCurState(char* sState)=0;

	virtual	INT		Update()=0;
};


INT LcopST_CreateSoul(char* sCmd
				 , ILopAi** pData
				 , void* p1			// CGameData::TcharMate*
				 , void* p2=0		// No Use
				 , void* p3=0		// No Use
				 , void* p4=0		// No Use
				 );

#endif

