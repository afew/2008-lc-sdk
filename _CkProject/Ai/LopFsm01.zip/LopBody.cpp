// Implementation of the ILopBody class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILopAi.h"
#include "LopSoul.h"

#include "ILopBody.h"


class CLopBody : public ILopBody
{
public:
	CLopBody();
	virtual ~CLopBody();

	virtual	INT		FrameMove();
	virtual	INT		Render();

	virtual	INT		SetBody(void* p);
};


CLopBody::CLopBody()
{
}

CLopBody::~CLopBody()
{
}

INT CLopBody::FrameMove()
{
	return 0;
}


INT CLopBody::Render()
{
	return 0;
}

INT	 CLopBody::SetBody(void* p)
{
	return 0;
}





INT LcopST_CreateBody(char* sCmd
				 , ILopBody** pData
				 , void* p1			// CGameData::TcharMate*
				 , void* p2			// No Use
				 , void* p3			// No Use
				 , void* p4			// No Use
				 )
{
	CLopBody*	p = new CLopBody;

	p->SetBody(p1);

	*pData = p;

	return 0;
}