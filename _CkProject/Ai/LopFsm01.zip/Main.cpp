

#include <windows.h> 
#include <stdio.h>


#include "ILopAi.h"
#include "LopSoul.h"
#include "ILopBody.h"



class CMiner : public CLopSoul
{
public:
	CMiner();
	virtual ~CMiner();

	INT		Create();
	void	Destroy();

	INT		FrameMove();
	void	Render();
};


struct MyState0 : _TLopState
{
	virtual INT	Enter();
	virtual INT	Leave();

	virtual INT	Exec();
};

INT MyState0::Enter()
{
	printf("MyState0::Enter()\n");
	return 0;
}

INT MyState0::Leave()
{
	printf("MyState0::Leave()\n");
	return 0;
}

INT MyState0::Exec()
{
	printf("MyState0::Exec()\n");
	return 0;
}


struct MyState1 : _TLopState
{
	virtual INT	Enter();
	virtual INT	Leave();

	virtual INT	Exec();
};

INT MyState1::Enter()
{
	printf("MyState1::Enter()\n");
	return 0;
}

INT MyState1::Leave()
{
	printf("MyState1::Leave()\n");
	return 0;
}

INT MyState1::Exec()
{
	printf("MyState1::Exec()\n");
	return 0;
}



struct MyState2 : _TLopState
{
	virtual INT	Enter();
	virtual INT	Leave();

	virtual INT	Exec();
};

INT MyState2::Enter()
{
	printf("MyState2::Enter()\n");
	return 0;
}

INT MyState2::Leave()
{
	printf("MyState2::Leave()\n");
	return 0;
}

INT MyState2::Exec()
{
	printf("MyState2::Exec()\n");
	return 0;
}





CMiner::CMiner()
{
}

CMiner::~CMiner()
{
}

INT CMiner::Create()
{
	return 0;
}

void CMiner::Destroy()
{
}

INT CMiner::FrameMove()
{
	this->Update();

	return 0;
}

void CMiner::Render()
{
}


void main()
{
	CMiner	pMiner;
	printf("Hello world\n");

	MyState0*	pState0 = new MyState0;
	MyState1*	pState1 = new MyState1;
	MyState2*	pState2 = new MyState2;

	pMiner.SetState

	while(1)
	{
		Sleep(100);
		pMiner.FrameMove();
	}
}