// Implementation of the ILopSoul class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILopAi.h"
#include "LopSoul.h"

#include "ILopBody.h"


CLopSoul::CLopSoul()
{
	m_pStOld	= NULL;		// Old State
	m_pStCur	= NULL;		// Current state
	m_pStInt	= NULL;		// Interrupt State
}

CLopSoul::~CLopSoul()
{
}


INT CLopSoul::SetStateCur(_TLopState* pV)
{
	m_pStCur	= pV;
	return 0;
}

INT CLopSoul::SetStateOld(_TLopState* pV)
{
	m_pStOld	= pV;
	return 0;
}


INT CLopSoul::SetStateInt(_TLopState* pV)
{
	m_pStInt	= pV;
	return 0;
}

INT CLopSoul::GetStateCur(_TLopState** pV)
{
	memcpy(*pV, m_pStCur, sizeof(_TLopState) );
	return 0;
}

INT CLopSoul::GetStateOld(_TLopState** pV)
{
	memcpy(*pV, m_pStOld, sizeof(_TLopState) );
	return 0;
}

INT CLopSoul::GetStateInt(_TLopState** pV)
{
	memcpy(*pV, m_pStInt, sizeof(_TLopState) );
	return 0;
}


INT CLopSoul::CompareCurState(char* pV)
{
	int hr = stricmp(m_pStCur->sValue+10, pV);

	if(0 == hr)
		return hr;

	return -1;
}


INT	 CLopSoul::SetSoul(void* p)
{
	return 0;
}





INT CLopSoul::Update()
{
	if(m_pStInt)
	{
	}
	

	if (m_pStCur)
	{
	}

	return 0;
}