// Implementation of the CStateMachine class.
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <memory.h>

#include "State.h"
#include "StateMachine.h"


_Tentity::_Tentity()
{
	m_nID	= 0xFFFFFFFF;
	m_iMp	= 0;
	m_pFSM	= NULL;
}

void _Tentity::SetID(int nID)
{
	m_nID	= nID;
}


int _Tentity::GetID()
{
	return m_nID;
}



int _Tentity::SetValue(char* sType, void* pValue)
{
	if(0 ==_stricmp("Stamina", sType))
	{
		m_iMp = (int)pValue;
		return 0;
	}

	return -1;
}

	

struct _TStateBase : public _Tstate
{
	char	sName[64];

	_TStateBase()
	{
		memset(sName, 0, sizeof sName);
	}

	virtual const char*	 const GetName() const
	{
		return sName;
	}

	void SetName(char* _sName)
	{
		strcpy(sName, _sName);
	}
};

struct _TStateIdle : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct _TStateWalk : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct _TStateRun : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct _TStateAttack : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct _TStateRest : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};



static mpTstate*	g_lsLopState	= NULL;


int Lop_StateListCreate()
{
	if(g_lsLopState)
		return 0;

	g_lsLopState	= new mpTstate;

	{	_TStateBase*	p = new _TStateIdle;	p->SetName("Idle"	);	g_lsLopState->insert(mpTstate::value_type("Idle"	, p));	}
	{	_TStateBase*	p = new _TStateWalk;	p->SetName("Walk"	);	g_lsLopState->insert(mpTstate::value_type("Walk"	, p));	}
	{	_TStateBase*	p = new _TStateRun;		p->SetName("Run"	);	g_lsLopState->insert(mpTstate::value_type("Run"		, p));	}
	{	_TStateBase*	p = new _TStateAttack;	p->SetName("Attack"	);	g_lsLopState->insert(mpTstate::value_type("Attack"	, p));	}
	{	_TStateBase*	p = new _TStateRest;	p->SetName("Rest"	);	g_lsLopState->insert(mpTstate::value_type("Rest"	, p));	}

	return 0;
}


void Lop_StateListDestroy()
{
	if(g_lsLopState)
	{
		itTstate	_F	= g_lsLopState->begin();
		itTstate	_L	= g_lsLopState->end();

		for( ; _F != _L; ++_F)
		{
			delete (*_F).second;
		}

		g_lsLopState->clear();

		delete g_lsLopState;
		g_lsLopState	= NULL;
	}
}


mpTstate* Lop_GetStateList()
{
	return g_lsLopState;
}



////////////////////////////////////////////////////////////////////////////////

int	_TStateIdle::Enter(_Tentity* pEntity)
{
	printf("Enter Idle(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateIdle::Exit(_Tentity* pEntity)
{
	printf("Exit Idle(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateIdle::Exec(_Tentity* pEntity)
{
	printf("Exec Idle(%4d): \n", pEntity->GetID());
	return 0;
}


////////////////////////////////////////////////////////////////////////////////

int	_TStateWalk::Enter(_Tentity* pEntity)
{
	printf("Enter Walk(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateWalk::Exit(_Tentity* pEntity)
{
	printf("Exit Walk(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateWalk::Exec(_Tentity* pEntity)
{
	if(pEntity->m_iMp<11)
		++pEntity->m_iMp;

	if(pEntity->m_iMp==10)
	{
		_Tstate*	pState	= pEntity->m_pFSM->GetStateOld();
		char*		sStOld	= (char*)pState->GetName();

		if(0== _stricmp("Run", sStOld))
		{
			_Tmessage pMessage(NULL, NULL, (char*)pState->GetName());
			pEntity->m_pFSM->OnMessage("Change State", &pMessage);
			return 0;
		}
	}

	printf("Exec Walk(%4d): \n", pEntity->GetID());

	return 0;
}


////////////////////////////////////////////////////////////////////////////////

int	_TStateRun::Enter(_Tentity* pEntity)
{
	printf("Enter Run(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateRun::Exit(_Tentity* pEntity)
{
	printf("Exit Run(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateRun::Exec(_Tentity* pEntity)
{
	--pEntity->m_iMp;

	if(pEntity->m_iMp<0)
	{
		pEntity->m_iMp = 0;
		_Tmessage pMessage(NULL, NULL, "Walk");
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
		return 0;
	}

	printf("Exec Run(%4d): \n", pEntity->GetID());
	return 0;
}


////////////////////////////////////////////////////////////////////////////////

int	_TStateAttack::Enter(_Tentity* pEntity)
{
	printf("Enter Attack(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateAttack::Exit(_Tentity* pEntity)
{
	printf("Exit Attack(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateAttack::Exec(_Tentity* pEntity)
{
	printf("Exec Attack(%4d): \n", pEntity->GetID());
	return 0;
}


////////////////////////////////////////////////////////////////////////////////

int	_TStateRest::Enter(_Tentity* pEntity)
{
	printf("Enter Rest(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateRest::Exit(_Tentity* pEntity)
{
	printf("Exit Rest(%4d): \n", pEntity->GetID());
	return 0;
}

int	_TStateRest::Exec(_Tentity* pEntity)
{
	++pEntity->m_iMp;

	if(pEntity->m_iMp>10)
	{
		_Tstate*	pState = pEntity->m_pFSM->GetStateOld();
		_Tmessage pMessage(NULL, NULL, (char*)pState->GetName());
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
		return 0;
	}

	printf("Exec Rest(%4d): %d \n", pEntity->GetID(), pEntity->m_iMp);

	return 0;
}


////////////////////////////////////////////////////////////////////////////////


