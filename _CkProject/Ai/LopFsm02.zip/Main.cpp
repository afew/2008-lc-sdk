

#include <windows.h> 
#include <stdio.h>

#include "State.h"
#include "StateMachine.h"



void main()
{
	if(FAILED(Lop_StateListCreate()))
		return;

	_Tentity*	pEntity = new _Tentity;

	pEntity->SetID(10);
	pEntity->SetValue("Stamina", (void*)5);
	pEntity->m_pFSM	= new CStateMachine;
	pEntity->m_pFSM->Create(pEntity);

	while(1)
	{
		Sleep(200);

		static int c=0;

		++c;

		if(c>80)
			break;

		if(c==4)
		{
			_Tmessage pMessage(NULL, NULL, "Walk");
			pEntity->m_pFSM->OnMessage("Change State", &pMessage);
		}

		if(c==8)
		{
			_Tmessage pMessage(NULL, NULL, "Run");
			pEntity->m_pFSM->OnMessage("Change State", &pMessage);
		}

		if(FAILED(pEntity->m_pFSM->Update()))
			break;
	}

	delete pEntity->m_pFSM;
	delete pEntity;


	Lop_StateListDestroy();
}