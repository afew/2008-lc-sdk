// Implementation of the CStateMachine class.
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <memory.h>

#include "State.h"
#include "StateMachine.h"


CStateMachine::CStateMachine()
{
	m_pStCur	= NULL;
	m_pStOld	= NULL;
	m_pStInt	= NULL;
}

CStateMachine::~CStateMachine()
{
}


int CStateMachine::Create(_Tentity* pEntity)
{
	m_pEntity	= pEntity;

	mpTstate*	pSt = Lop_GetStateList();
	itTstate	it	= pSt->find("Idle");

	if( it != pSt->end())
		m_pStCur = (*it).second;


	return 0;
}


int CStateMachine::Update()
{
	if(m_pStInt)
	{
		m_pStInt->Exec(m_pEntity);
		return 0;
	}

	if(m_pStCur)
		m_pStCur->Exec(m_pEntity);

	return 0;
}


int CStateMachine::OnMessage(char* sMsg, _Tmessage* pMessage)
{
	if(0==_stricmp("Change State", sMsg))
	{
		mpTstate*	pSt = Lop_GetStateList();
		itTstate	it	= pSt->find(pMessage->sValue);

		if( it == pSt->end())
			return -1;


		m_pStCur->Exit(m_pEntity);

		m_pStOld	= m_pStCur;
		
		m_pStCur = (*it).second;
		m_pStCur->Enter(m_pEntity);

		return 0;
	}


	return -1;
}



_Tstate* CStateMachine::GetStateOld()
{
	return m_pStOld;	// Old State
}