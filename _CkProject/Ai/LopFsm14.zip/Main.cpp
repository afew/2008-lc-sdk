

#include <windows.h> 
#include <stdio.h>

#include "ILopAi.h"
#include "ocAmun.h"
#include "Miner.h"


void main()
{
	if(FAILED(ILopAi::Lop_StateListCreate()))
		return;

	CMiner*	pEnt1 = new CMiner;
	CMiner*	pEnt2 = new CMiner;

	pEnt1->Create((void*)10, (void*)1);
	pEnt2->Create((void*)20, (void*)3);

	static int c=0;


	while(1)
	{
		Sleep(500);

		if(++c>50)
			break;

		if(FAILED(pEnt1->Update()))
			break;

		if(FAILED(pEnt2->Update()))
			break;
	}

	pEnt1->Destroy();
	delete pEnt1;


	pEnt2->Destroy();
	delete pEnt2;


	ILopAi::Lop_StateListDestroy();
}