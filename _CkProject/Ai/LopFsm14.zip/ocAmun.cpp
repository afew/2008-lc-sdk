// Implementation of the TocAmun class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>

#include "ILopAi.h"
#include "ocAmun.h"


int TocAmun::Create(void* p1,void* p2,void* p3,void* p4)
{
	if(FAILED(_Tentity::Create(p1, p2, p3, p4)))
		return -1;

	return 0;
}

void TocAmun::Destroy()
{
	_Tentity::Destroy();
}


int TocAmun::Update()
{
	return 0;
}


int TocAmun::QueryState(char* sCmd, void* pData)
{
	if(FAILED(_Tentity::QueryState(sCmd, pData)))
		return -1;

	return 0;
}