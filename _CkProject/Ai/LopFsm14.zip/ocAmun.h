// Interface for the CocAmun class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _TocAmun_H_
#define _TocAmun_H_

struct TocAmun : public ILopAi::_Tentity
{

	INT			KaBa;				// Man[0: Human, arc: 1], Woman[2: Human, Arc: 3]
	INT			Active;				// Activation
	void*		pData;				// Model 3D Data

	char		sName[64];			// Character Name

	virtual	int		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	int		Update();
	virtual	int		QueryState(char* sCmd, void* pData);
};

#endif


