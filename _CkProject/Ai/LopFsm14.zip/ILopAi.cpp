// Implementation of the _TstateMachine class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>

#include "ILopAi.h"


////////////////////////////////////////////////////////////////////////////////
namespace ILopAi
{

_Tentity::_Tentity()
{
	m_nID	= 0xFFFFFFFF;
	m_pFSM	= NULL;
}


_Tentity::~_Tentity()
{
}


int _Tentity::Create(void*, void*, void*, void*)
{
	return 0;
}

void _Tentity::Destroy()
{
}


int _Tentity::Update()
{
	return 0;
}


int _Tentity::QueryState(char* sCmd, void* pData)
{
	return 0;
}


int _Tentity::OnMessage(char* sMsg, void* pMessage)
{
	_TstateMachine*	pFSM = (_TstateMachine*)m_pFSM;
	return pFSM->OnMessage(sMsg, (_Tmessage*)pMessage);
}


void _Tentity::SetID(int nID)
{
	m_nID	= nID;
}


int _Tentity::GetID()
{
	return m_nID;
}



////////////////////////////////////////////////////////////////////////////////

struct _TStateBase : public _Tstate
{
	char	sName[64];

	_TStateBase()
	{
		memset(sName, 0, sizeof sName);
	}

	_TStateBase(const char* _sName)
	{
		memset(sName, 0, sizeof sName);
		strcpy(sName, _sName);
	}

	virtual const char*	 const GetName() const
	{
		return sName;
	}

	void SetName(char* _sName)
	{
		strcpy(sName, _sName);
	}


	virtual int	Enter(_Tentity* pEntity);				// Enter State
	virtual int	Exit(_Tentity* pEntity);				// Exit State
	virtual int	Exec(_Tentity* pEntity);				// Excute State
};


int	_TStateBase::Enter(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Enter %s", sName);
	return pEntity->QueryState(sCmd, NULL);
}

int	_TStateBase::Exit(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Exit %s", sName);
	return pEntity->QueryState(sCmd, NULL);
}

int	_TStateBase::Exec(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Exec %s", sName);
	return pEntity->QueryState(sCmd, NULL);
}


////////////////////////////////////////////////////////////////////////////////

static mpTstate*	g_lsLopState	= NULL;

int Lop_StateListCreate()
{
	if(g_lsLopState)
		return 0;

	g_lsLopState	= new mpTstate;

	{	_Tstate* p = new _TStateBase("Mine"	 );	g_lsLopState->insert(mpTstate::value_type("Mine"   , p));	}
	{	_Tstate* p = new _TStateBase("Bank"	 );	g_lsLopState->insert(mpTstate::value_type("Bank"   , p));	}
	{	_Tstate* p = new _TStateBase("Home"	 );	g_lsLopState->insert(mpTstate::value_type("Home"   , p));	}
	{	_Tstate* p = new _TStateBase("Saloon");	g_lsLopState->insert(mpTstate::value_type("Saloon" , p));	}

	return 0;
}


void Lop_StateListDestroy()
{
	if(g_lsLopState)
	{
		itTstate	_F	= g_lsLopState->begin();
		itTstate	_L	= g_lsLopState->end();

		for( ; _F != _L; ++_F)
			delete (*_F).second;

		g_lsLopState->clear();

		delete g_lsLopState;
		g_lsLopState	= NULL;
	}
}


mpTstate* Lop_GetStateList()
{
	return g_lsLopState;
}




////////////////////////////////////////////////////////////////////////////////
_TstateMachine::_TstateMachine()
{
	m_pStCur	= NULL;
	m_pStOld	= NULL;
	m_pStInt	= NULL;
}

_TstateMachine::~_TstateMachine()
{
}


int _TstateMachine::Create(_Tentity* pEntity)
{
	m_pEntity	= pEntity;

	_Tmessage pMessage(NULL, NULL, "Mine");
	this->OnMessage("Change State", &pMessage);


	return 0;
}


int _TstateMachine::Update()
{
	if(m_pStInt)
	{
		m_pStInt->Exec(m_pEntity);
		return 0;
	}

	if(m_pStCur)
		m_pStCur->Exec(m_pEntity);

	return 0;
}


int _TstateMachine::OnMessage(char* sMsg, _Tmessage* pMessage)
{
	if(0==_stricmp("Change State", sMsg))
	{
		mpTstate*	pSt = Lop_GetStateList();
		itTstate	it	= pSt->find(pMessage->sValue);

		if( it == pSt->end())
			return -1;

		if(m_pStCur)
			m_pStCur->Exit(m_pEntity);

		m_pStOld	= m_pStCur;
		
		m_pStCur = (*it).second;
		m_pStCur->Enter(m_pEntity);

		return 0;
	}


	return -1;
}

_Tstate* _TstateMachine::GetStateCur()	{	return m_pStCur;	}
_Tstate* _TstateMachine::GetStateOld()	{	return m_pStOld;	}
_Tstate* _TstateMachine::GetStateInt()	{	return m_pStInt;	}


}// namespace ILopAi::