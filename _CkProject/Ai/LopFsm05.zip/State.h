// Interface for the CState class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _State_H_
#define _State_H_

#pragma warning(disable: 4786)

#include <map>
#include <string>
using namespace std;

class CStateMachine;

struct _Tentity
{
	int	m_nID;
	int	m_iMp;

	CStateMachine*	m_pFSM;

	_Tentity();

	int		GetID();
	void	SetID(int nID);

	int		Query(char* sCmd, void* pData);

	virtual	int		Create(void* =0,void* =0,void* =0,void* =0)=0;
	virtual	void	Destroy()=0;
	virtual	int		Update()=0;
};


struct	_Tmessage
{
	void*	pSender;			//the entity that sent this telegram
	char	sValue[128];
	void*	pExtra;				// Extra data exceed sValue
	float	fDelay;				// Dispatch Time: 0 is No delay

	_Tmessage()
	{
		pSender		= NULL;

		pExtra		= NULL;
		fDelay		= NULL;

		memset(sValue, 0, sizeof(sValue));
	}


	_Tmessage(void*	_pSender, void*	_pReceiver, char* _sMsg, float _fDelay =0.f, void* _pExtra = NULL)
	{
		pSender		= _pSender;
		fDelay		= _fDelay;
		pExtra		= _pExtra;

		memcpy(sValue, _sMsg, sizeof(sValue));
	}

};

struct _Tstate
{
	virtual int	Enter(_Tentity* pEntity)=0;				// Enter State
	virtual int	Exit(_Tentity* pEntity)=0;				// Exit State
	virtual int	Exec(_Tentity* pEntity)=0;				// Excute State

	virtual const char*	 const GetName() const =0;		// Get State Name
};


typedef	std::map<std::string, _Tstate*	>	mpTstate;
typedef	mpTstate::iterator					itTstate;


int			Lop_StateListCreate();
void		Lop_StateListDestroy();

mpTstate*	Lop_GetStateList();




enum location_type
{
  shack,
  goldmine,
  bank,
  saloon
};


//the amount of gold a miner must have before he feels he can go home
const int ComfortLevel       = 5;
//the amount of nuggets a miner can carry
const int MaxNuggets         = 3;
//above this value a miner is thirsty
const int ThirstLevel        = 5;
//above this value a miner is sleepy
const int TirednessThreshold = 5;

class Miner : public _Tentity
{
public:
	location_type         m_Location;
	int                   m_iGoldCarried;
	int                   m_iMoneyInBank;
	int                   m_iThirst;
	int                   m_iFatigue;
public:
	Miner()
	{
		m_Location		= shack;
		m_iGoldCarried	= 0;
		m_iMoneyInBank	= 0;
		m_iThirst		= 0;
		m_iFatigue		= 0;
	}

	virtual	int		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	int		Update();

	location_type Location()const{return m_Location;}	
	void          ChangeLocation(location_type loc){m_Location=loc;}

	int           GoldCarried()const{return m_iGoldCarried;}
	void          SetGoldCarried(int val){m_iGoldCarried = val;}
	void          AddToGoldCarried(int val);
	bool          PocketsFull()const{return m_iGoldCarried >= MaxNuggets;}

	bool          Fatigued()const;
	void          DecreaseFatigue(){m_iFatigue -= 1;}
	void          IncreaseFatigue(){m_iFatigue += 1;}

	int           Wealth()const{return m_iMoneyInBank;}
	void          SetWealth(int val){m_iMoneyInBank = val;}
	void          AddToWealth(int val);

	bool          Thirsty()const; 
	void          BuyAndDrinkAWhiskey(){m_iThirst = 0; m_iMoneyInBank-=2;}
};


#endif

