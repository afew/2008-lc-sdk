

#include <windows.h> 
#include <stdio.h>

#include "State.h"
#include "StateMachine.h"

void main()
{
	if(FAILED(Lop_StateListCreate()))
		return;

	Miner*	pEnt1 = new Miner;
	Miner*	pEnt2 = new Miner;

	pEnt1->Create((void*)10, (void*)1);
	pEnt2->Create((void*)20, (void*)3);


	while(1)
	{
		Sleep(1000);

		if(FAILED(pEnt1->Update()))
			break;

		if(FAILED(pEnt2->Update()))
			break;
	}

	pEnt1->Destroy();
	delete pEnt1;


	pEnt2->Destroy();
	delete pEnt2;


	Lop_StateListDestroy();
}