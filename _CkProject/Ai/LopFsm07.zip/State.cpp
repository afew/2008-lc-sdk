// Implementation of the CStateMachine class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>

#include "State.h"
#include "StateMachine.h"


_Tentity::_Tentity()
{
	m_nID	= 0xFFFFFFFF;
	m_pFSM	= NULL;
}

_Tentity::~_Tentity()
{
	CStateMachine*	pFSM = (CStateMachine*)m_pFSM;

	if(pFSM)
	{
		delete pFSM;
		pFSM = NULL;
	}
}

int _Tentity::Create(void*, void*, void*, void*)
{
	return -1;
}

void _Tentity::Destroy()
{
}


int _Tentity::Update()
{
	return -1;
}

int _Tentity::QueryState(char* sCmd, void* pData)
{
	return -1;
}

int _Tentity::OnMessage(char* sMsg, void* pMessage)
{
	CStateMachine*	pFSM = (CStateMachine*)m_pFSM;
	return pFSM->OnMessage(sMsg, (_Tmessage*)pMessage);
}

void _Tentity::SetID(int nID)
{
	m_nID	= nID;
}


int _Tentity::GetID()
{
	return m_nID;
}





	

struct _TStateBase : public _Tstate
{
	char	sName[64];

	_TStateBase()
	{
		memset(sName, 0, sizeof sName);
	}

	virtual const char*	 const GetName() const
	{
		return sName;
	}

	void SetName(char* _sName)
	{
		strcpy(sName, _sName);
	}
};

struct EnterMineAndDigForNugget : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct VisitBankAndDepositGold : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct GoHomeAndSleepTilRested : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct QuenchTirst : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};




static mpTstate*	g_lsLopState	= NULL;


int Lop_StateListCreate()
{
	if(g_lsLopState)
		return 0;

	g_lsLopState	= new mpTstate;

	{	_TStateBase*	p = new EnterMineAndDigForNugget;	p->SetName("EnterMine"	);	g_lsLopState->insert(mpTstate::value_type("EnterMine"	, p));	}
	{	_TStateBase*	p = new VisitBankAndDepositGold;	p->SetName("VisitBank"	);	g_lsLopState->insert(mpTstate::value_type("VisitBank"	, p));	}
	{	_TStateBase*	p = new GoHomeAndSleepTilRested;	p->SetName("GoHome"		);	g_lsLopState->insert(mpTstate::value_type("GoHome"		, p));	}
	{	_TStateBase*	p = new QuenchTirst;				p->SetName("QuenchTirst");	g_lsLopState->insert(mpTstate::value_type("QuenchTirst"	, p));	}


	return 0;
}


void Lop_StateListDestroy()
{
	if(g_lsLopState)
	{
		itTstate	_F	= g_lsLopState->begin();
		itTstate	_L	= g_lsLopState->end();

		for( ; _F != _L; ++_F)
		{
			delete (*_F).second;
		}

		g_lsLopState->clear();

		delete g_lsLopState;
		g_lsLopState	= NULL;
	}
}


mpTstate* Lop_GetStateList()
{
	return g_lsLopState;
}



////////////////////////////////////////////////////////////////////////////////

int	EnterMineAndDigForNugget::Enter(_Tentity* pEntity)
{
	return pEntity->QueryState("Enter Mine", NULL);
}

int	EnterMineAndDigForNugget::Exit(_Tentity* pEntity)
{
	return pEntity->QueryState("Exit Mine", NULL);
}

int	EnterMineAndDigForNugget::Exec(_Tentity* pEntity)
{
	return pEntity->QueryState("Exec Mine", NULL);
}


////////////////////////////////////////////////////////////////////////////////

int	VisitBankAndDepositGold::Enter(_Tentity* pEntity)
{
	return pEntity->QueryState("Enter Bank", NULL);
}

int	VisitBankAndDepositGold::Exit(_Tentity* pEntity)
{
	return pEntity->QueryState("Enter Bank", NULL);
}

int	VisitBankAndDepositGold::Exec(_Tentity* pEntity)
{
	return pEntity->QueryState("Exec Bank", NULL);
}


////////////////////////////////////////////////////////////////////////////////

int	GoHomeAndSleepTilRested::Enter(_Tentity* pEntity)
{
	return pEntity->QueryState("Enter Home", NULL);
}

int	GoHomeAndSleepTilRested::Exit(_Tentity* pEntity)
{
	return pEntity->QueryState("Exit Home", NULL);
}

int	GoHomeAndSleepTilRested::Exec(_Tentity* pEntity)
{
	return pEntity->QueryState("Exec Home", NULL);
}


int	QuenchTirst::Enter(_Tentity* pEntity)
{
	return pEntity->QueryState("Enter Saloon", NULL);
}

int	QuenchTirst::Exit(_Tentity* pEntity)
{
	return pEntity->QueryState("Exit Saloon", NULL);
}

int	QuenchTirst::Exec(_Tentity* pEntity)
{
	return pEntity->QueryState("Exec Saloon", NULL);
}


////////////////////////////////////////////////////////////////////////////////
