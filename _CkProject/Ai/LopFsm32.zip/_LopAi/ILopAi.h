// Interface for the ILopAi class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILopAi_H_
#define _ILopAi_H_

#pragma warning(disable: 4786)

#include <vector>
#include <list>
#include <map>
#include <string>

using namespace std;


namespace ILopAi
{

enum EocState
{
	OCST_NONE,
	OCST_IDLE,
	OCST_WALK,
	OCST_RUN,
	OCST_DASH,
	OCST_ATTACK,
	OCST_DAMAGE
};

class _Tentity
{
protected:
	INT		m_nID;
	void*	m_pFSM;

public:
	_Tentity();
	virtual ~_Tentity();

	virtual	INT		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	INT		Update();
	virtual	INT		QueryState(char* sCmd, void* pData);
	virtual	INT		QueryValue(char* sCmd, void* pData);

	INT		OnMessage(char* sMsg, void* pMessage);
	INT		GetID();
	void	SetID(INT nID);
};


enum EocValue
{
	MAX_STATE_NAME	= 32,
	MAX_MSG_VALUE	= 64,
	CMD_ONCE		= 0,
	CMD_LOOP		= 1,
	MAX_LIFE		= 0x003FF,	//0x00FFFFFF,	// 16 * 1000 �� ~ 267��~ 4.4 �ð�
};


struct	_Tmessage
{
	char	Phase[ILopAi::MAX_STATE_NAME];
	char	Value[ILopAi::MAX_MSG_VALUE];

	INT		CmdType;			// 0: 1���� ����, 1: Loop Command
	void*	Sender;				// Message ������

	void*	Extra;				// Extra data exceed Value

	DWORD	TimeCur;			// Sending Time or Current Time
	INT		TimeDly;			// Delay Time: 0 is No delay
	INT		TimeDur;			// Duration Time

	_Tmessage();
	_Tmessage(const _Tmessage& r);
	_Tmessage(const _Tmessage* r);

	_Tmessage(char* sPhase
			, char* sMsg
			, INT	nType	= ILopAi::CMD_ONCE
			, void* Sender	= NULL
			, INT	Delay	= 0
			, INT	Duration= ILopAi::MAX_LIFE
			);	// 64Byte �̳� ������

	_Tmessage(char*	sPhase
			, void*	pMsg
			, INT	nSize
			, INT	nType	= ILopAi::CMD_ONCE
			, void*	Sender	= NULL
			, INT	Delay	= 0
			, INT	Duration = ILopAi::MAX_LIFE
			);	// 64Byte �ʰ� ������

	const _Tmessage& operator=(const _Tmessage& r);	// r: right hand side(rhs)
	const _Tmessage& operator=(const _Tmessage* r);	// r: right hand side(rhs)
};



struct _Tstate
{
	BOOL		Active;
	_Tmessage	Message;

	_Tstate();
	_Tstate(const _Tmessage&);
	_Tstate(const _Tmessage*);
	
	INT		Enter(_Tentity* pEntity);				// Enter State
	INT		Exit(_Tentity* pEntity);				// Exit State
	INT		Exec(_Tentity* pEntity);				// Excute State

	const _Tmessage* const GetPhase() const;
	const char*		 const GetPhaseName() const;

	void	SetPhase(const _Tmessage* );
	void	SetPhaseName(const char*);
	void	SetActive(BOOL bActive);
	BOOL	GetActive();
};


typedef	std::map<std::string, _Tstate*	>	mpTstate;
typedef	mpTstate::iterator					itTstate;

typedef	std::list<_Tmessage >	lsTmsg;
typedef	lsTmsg::iterator		isTmsg;

typedef	std::vector<_Tmessage >	lvTmsg;
typedef	lvTmsg::iterator		ivTmsg;

class _TstateFSM
{
protected:
	_Tentity*	m_pEntity;

	_Tstate*	m_pStCur;	// Current State
	_Tstate*	m_pStOld;	// Old State
	_Tstate*	m_pStInt;	// Interrupt State

	lsTmsg		m_LsEvt;	// Event State List
	lvTmsg		m_LvAgt;	// Agent List

public:
	_TstateFSM();
	virtual ~_TstateFSM();

	INT			Create(_Tentity* pEntity);
	void		Destroy();
	INT			Update();

	INT			OnMessage(char* sMsg, _Tmessage* pMessage);

	_Tstate*	GetStateCur();
	_Tstate*	GetStateOld();
	_Tstate*	GetStateInt();
};

}//name space ILopAi


#endif

