// Implementation of the _TstateFSM class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <memory.h>
#include <mmsystem.h>

#include "ILopAi.h"


#ifndef SAFE_DELETE
#define SAFE_DELETE(p)			{ if(p){ delete    p; p = NULL; } }
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p)	{ if(p){ delete [] p; p = NULL;	} }
#endif

////////////////////////////////////////////////////////////////////////////////
namespace ILopAi
{

_Tentity::_Tentity()
{
	m_nID	= 0xFFFFFFFF;
	m_pFSM	= NULL;
}


_Tentity::~_Tentity()
{
}


INT _Tentity::Create(void* p1, void*, void*, void*)
{
	INT nId = (INT)p1;
	SetID(nId);

	return 0;
}

void _Tentity::Destroy()
{
}


INT _Tentity::Update()
{
	return 0;
}


INT _Tentity::QueryState(char* sCmd, void* pData)
{
	return -1;
}


INT _Tentity::QueryValue(char* sCmd, void* pData)
{
	if(0 ==_stricmp(sCmd, "Get ID"))
	{
		*((INT*)pData)	= m_nID;
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Set ID"))
	{
		m_nID = *((INT*)pData);
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Get FSM"))
	{
		*((void**)pData)	= m_pFSM;
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Set FSM"))
	{
		m_pFSM = *((void**)pData);
		return 0;
	}

	return -1;
}

INT _Tentity::OnMessage(char* sMsg, void* pMessage)
{
	_TstateFSM*	pFSM = (_TstateFSM*)m_pFSM;
	return pFSM->OnMessage(sMsg, (_Tmessage*)pMessage);
}


void _Tentity::SetID(INT nID)
{
	m_nID	= nID;
}


INT _Tentity::GetID()
{
	return m_nID;
}



////////////////////////////////////////////////////////////////////////////////

_Tstate::_Tstate()
{
	memset(Phase, 0, ILopAi::MAX_STATE_NAME);
}

_Tstate::_Tstate(const char* _sName)
{
	memset(Phase, 0, ILopAi::MAX_STATE_NAME);
	strcpy(Phase, _sName);
}

INT	_Tstate::Enter(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Enter %s", Phase);
	return pEntity->QueryState(sCmd, NULL);
}

INT	_Tstate::Exit(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Exit %s", Phase);

	if(0==strlen(Phase))
		return -1;

	return pEntity->QueryState(sCmd, NULL);
}

INT	_Tstate::Exec(_Tentity* pEntity)
{
	char	sCmd[64]={0};
	sprintf(sCmd, "Exec %s", Phase);
	return pEntity->QueryState(sCmd, NULL);
}


const char*	 const _Tstate::GetName() const
{
	return Phase;
}

void _Tstate::SetName(const char* _sName)
{
	strcpy(Phase,  _sName);
}

////////////////////////////////////////////////////////////////////////////////
_Tmessage::_Tmessage()
{
	CmdType		= 0;
	Sender		= NULL;
	Extra		= NULL;
	Delay		= 0;
	TimeBgn		= 0;

	memset(Phase, 0, ILopAi::MAX_STATE_NAME);
	memset(Value, 0, ILopAi::MAX_MSG_VALUE);
}


// 64Byte �̳� ������
_Tmessage::_Tmessage(char* sPhs, char* sMsg, INT nType, void* pSender, float fDelay)
{
	CmdType		= nType;
	Sender		= pSender;
	Extra		= NULL;
	Delay		= fDelay;
	TimeBgn		= ::timeGetTime();

	memcpy(Phase, sPhs, ILopAi::MAX_STATE_NAME);

	memset(Value, 0, ILopAi::MAX_MSG_VALUE);
	if(sMsg)
		memcpy(Value, sMsg, ILopAi::MAX_MSG_VALUE);
}

// 64Byte �ʰ� ������
_Tmessage::_Tmessage(char* sPhs, void* pMsg, INT nSize, INT nType, void* pSender, float fDelay)
{
	CmdType		= nType;
	Sender		= pSender;
	Extra		= pMsg;
	Delay		= fDelay;
	TimeBgn		= ::timeGetTime();

	memcpy(Phase, sPhs, ILopAi::MAX_STATE_NAME);

	memset(Value, 0, ILopAi::MAX_MSG_VALUE);
	if(pMsg)
		memcpy(Value, &nSize, sizeof(INT));
}



const _Tmessage& _Tmessage::operator=(const _Tmessage& r)	// r: right hand side(rhs)
{	
	CmdType		= r.CmdType;
	Sender		= r.Sender;
	Extra		= r.Extra;
	Delay		= r.Delay;
	TimeBgn		= r.TimeBgn;

	memcpy(Phase, r.Phase, ILopAi::MAX_STATE_NAME);
	memcpy(Value, r.Value, ILopAi::MAX_MSG_VALUE);

	return *this;
}

const _Tmessage& _Tmessage::operator=(const _Tmessage* r)	// r: right hand side(rhs)
{	
	CmdType		= r->CmdType;
	Sender		= r->Sender;
	Extra		= r->Extra;
	Delay		= r->Delay;
	TimeBgn		= r->TimeBgn;

	memcpy(Phase, r->Phase, ILopAi::MAX_STATE_NAME);
	memcpy(Value, r->Value, ILopAi::MAX_MSG_VALUE);

	return *this;
}


////////////////////////////////////////////////////////////////////////////////
_TstateFSM::_TstateFSM() : m_pStEvt(0)
{
	m_pStCur	= NULL;
	m_pStOld	= NULL;
	m_pStInt	= NULL;
}

_TstateFSM::~_TstateFSM()
{
	SAFE_DELETE(	m_pStCur	);
	SAFE_DELETE(	m_pStOld	);
	SAFE_DELETE(	m_pStInt	);

	m_pStEvt.clear();
}


INT _TstateFSM::Create(_Tentity* pEntity)
{
	m_pEntity	= pEntity;

	m_pStCur	= new _Tstate;
	m_pStOld	= new _Tstate;
	m_pStInt	= new _Tstate;

	_Tmessage pMessage("Idle", NULL);
	this->OnMessage("Change State", &pMessage);

	return 0;
}


INT _TstateFSM::Update()
{
	DWORD	dCur = ::timeGetTime();

	if(!m_pStEvt.empty())
	{
		itTmessage	_F	= m_pStEvt.begin();
		itTmessage	_L	= m_pStEvt.end();

		for(; _F != _L; ++_F)
		{
			FLOAT	Delay = (*_F).Delay;
			(*_F).Delay = Delay -(dCur - (*_F).TimeBgn);
			(*_F).TimeBgn = dCur;
		}

		_F	= m_pStEvt.begin();

		if( (*_F).Delay<=0.f)
		{
			(*_F).Delay = 0;
			_Tmessage t = (*_F);

			this->OnMessage("Change State", &t);
			m_pStEvt.erase(_F);
		}
	}

	if( strlen(m_pStInt->Message.Phase))
	{
		m_pStInt->Exec(m_pEntity);
		return 0;
	}

	if( strlen(m_pStCur->Message.Phase))
		m_pStCur->Exec(m_pEntity);

	return 0;
}


INT _TstateFSM::OnMessage(char* sMsg, _Tmessage* pMessage)
{
	if(0==_stricmp("Change State", sMsg))
	{
		// Delay�� ���� ��� �ٷ� ����
		if(0 >= pMessage->Delay)
		{
			int hr;
			char	sCmd[64]={0};
			sprintf(sCmd, "Enter %s", pMessage->Phase);

			// ���� ���¿��� ���� ������.
			m_pStCur->Exit(m_pEntity);

			// ���ο� ���°� �������� Ȯ���Ѵ�.
			hr = m_pEntity->QueryState(sCmd, pMessage);

			// ���� ������ ���� �����Ѵ�.
			if(SUCCEEDED(hr))
			{
				memcpy(&m_pStCur->Message, pMessage, sizeof(ILopAi::_Tmessage));
				memcpy(m_pStOld, m_pStCur, sizeof(ILopAi::_Tstate) );
			}
		}

		// �켱 ���� ť�� �ִ´�.
		else
		{
			_Tmessage	t	= *pMessage;
			itTmessage	_F	= m_pStEvt.begin();
			itTmessage	_L	= m_pStEvt.end();

			for(; _F != _L; ++_F)
			{
				if(t.Delay< (*_F).Delay)
					break;
			}

			m_pStEvt.insert(_F, t);
		}

		return 0;
	}


	return -1;
}

_Tstate* _TstateFSM::GetStateCur()	{	return m_pStCur;	}
_Tstate* _TstateFSM::GetStateOld()	{	return m_pStOld;	}
_Tstate* _TstateFSM::GetStateInt()	{	return m_pStInt;	}



}// namespace ILopAi