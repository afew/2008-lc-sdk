// Interface for the CState class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _State_H_
#define _State_H_

#pragma warning(disable: 4786)

#include <map>
#include <string>
using namespace std;


namespace	ILopAi
{

enum EocState
{
	OCST_NONE,
	OCST_IDLE,
	OCST_WALK,
	OCST_RUN,
	OCST_DASH,
	OCST_ATTACK,
	OCST_DAMAGE
};

class _Tentity
{
protected:
	INT		m_nID;
	void*	m_pFSM;

public:
	_Tentity();
	virtual ~_Tentity();

	virtual	INT		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	INT		Update();
	virtual	INT		QueryState(char* sCmd, void* pData);
	virtual	INT		QueryValue(char* sCmd, void* pData);

	INT		OnMessage(char* sMsg, void* pMessage);
	INT		GetID();
	void	SetID(INT nID);
};



struct	_Tmessage
{
	void*	pSender;			//the entity that sent this telegram
	char	sValue[128];
	void*	pExtra;				// Extra data exceed sValue
	float	fDelay;				// Dispatch Time: 0 is No delay

	_Tmessage()
	{
		pSender		= NULL;
		pExtra		= NULL;
		fDelay		= NULL;

		memset(sValue, 0, sizeof(sValue));
	}


	_Tmessage(void*	_pSender, void*	_pReceiver, char* _sMsg, float _fDelay =0.f, void* _pExtra = NULL)
	{
		pSender		= _pSender;
		fDelay		= _fDelay;
		pExtra		= _pExtra;

		memcpy(sValue, _sMsg, sizeof(sValue));
	}

};

struct _Tstate
{
	virtual INT	Enter(_Tentity* pEntity)=0;				// Enter State
	virtual INT	Exit(_Tentity* pEntity)=0;				// Exit State
	virtual INT	Exec(_Tentity* pEntity)=0;				// Excute State

	virtual const char*	 const GetName() const =0;		// Get State Name
};


typedef	std::map<std::string, _Tstate*	>	mpTstate;
typedef	mpTstate::iterator					itTstate;


class _TstateFSM
{
protected:
	_Tentity*	m_pEntity;

	_Tstate*	m_pStCur;	// Current State
	_Tstate*	m_pStOld;	// Old State
	_Tstate*	m_pStInt;	// Interrupt State

public:
	_TstateFSM();
	virtual ~_TstateFSM();

	INT			Create(_Tentity* pEntity);
	INT			Update();

	INT			OnMessage(char* sMsg, _Tmessage* pMessage);

	_Tstate*	GetStateCur();
	_Tstate*	GetStateOld();
	_Tstate*	GetStateInt();
};



INT			Lop_StateListCreate(char* []);
void		Lop_StateListDestroy();
mpTstate*	Lop_GetStateList();

}//name space ILopAi


#endif

