// Implementation of the CStateMachine class.
//
////////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <memory.h>

#include "State.h"
#include "StateMachine.h"


_Tentity::_Tentity()
{
	m_nID	= 0xFFFFFFFF;
	m_iMp	= 0;
	m_pFSM	= NULL;
}

void _Tentity::SetID(int nID)
{
	m_nID	= nID;
}


int _Tentity::GetID()
{
	return m_nID;
}



int _Tentity::Query(char* sCmd, void* pData)
{
	if(0 ==_stricmp("Set Stamina", sCmd))
	{
		m_iMp = (int)pData;
		return 0;
	}

	return -1;
}

	

struct _TStateBase : public _Tstate
{
	char	sName[64];

	_TStateBase()
	{
		memset(sName, 0, sizeof sName);
	}

	virtual const char*	 const GetName() const
	{
		return sName;
	}

	void SetName(char* _sName)
	{
		strcpy(sName, _sName);
	}
};

struct EnterMineAndDigForNugget : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct VisitBankAndDepositGold : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct GoHomeAndSleepTilRested : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};


struct QuenchTirst : public _TStateBase
{
	virtual int	Enter(_Tentity* pEntity);
	virtual int	Exit(_Tentity* pEntity);
	virtual int	Exec(_Tentity* pEntity);
};




static mpTstate*	g_lsLopState	= NULL;


int Lop_StateListCreate()
{
	if(g_lsLopState)
		return 0;

	g_lsLopState	= new mpTstate;

	{	_TStateBase*	p = new EnterMineAndDigForNugget;	p->SetName("EnterMine"	);	g_lsLopState->insert(mpTstate::value_type("EnterMine"	, p));	}
	{	_TStateBase*	p = new VisitBankAndDepositGold;	p->SetName("VisitBank"	);	g_lsLopState->insert(mpTstate::value_type("VisitBank"	, p));	}
	{	_TStateBase*	p = new GoHomeAndSleepTilRested;	p->SetName("GoHome"		);	g_lsLopState->insert(mpTstate::value_type("GoHome"		, p));	}
	{	_TStateBase*	p = new QuenchTirst;				p->SetName("QuenchTirst");	g_lsLopState->insert(mpTstate::value_type("QuenchTirst"	, p));	}


	return 0;
}


void Lop_StateListDestroy()
{
	if(g_lsLopState)
	{
		itTstate	_F	= g_lsLopState->begin();
		itTstate	_L	= g_lsLopState->end();

		for( ; _F != _L; ++_F)
		{
			delete (*_F).second;
		}

		g_lsLopState->clear();

		delete g_lsLopState;
		g_lsLopState	= NULL;
	}
}


mpTstate* Lop_GetStateList()
{
	return g_lsLopState;
}



////////////////////////////////////////////////////////////////////////////////

int	EnterMineAndDigForNugget::Enter(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;
	
	if(pMiner->Location() !=goldmine)
	{
		printf("(%4d): ��Walkin�� to the Gold Mine\n", nId );
		pMiner->ChangeLocation(goldmine);
		return 0;
	}
	return 0;
}

int	EnterMineAndDigForNugget::Exit(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	printf("(%4d): ��Ah m leavin�� the gold mine with mah pockets full oh sweet gold\n", nId );

	return 0;
}

int	EnterMineAndDigForNugget::Exec(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;


	pMiner->AddToGoldCarried(1);
	pMiner->IncreaseFatigue();

	printf("(%4d): ��Pickin�� up a nugget\n", nId );

	if(pMiner->PocketsFull())
	{
		_Tmessage pMessage(NULL, NULL, "VisitBank");
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
	}

	if(pMiner->Thirsty())
	{
		_Tmessage pMessage(NULL, NULL, "QuenchTirst");
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
		return 0;
	}

	return 0;
}


////////////////////////////////////////////////////////////////////////////////

int	VisitBankAndDepositGold::Enter(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	if (pMiner->Location() != bank)
	{
		printf("(%4d): ��Goin' to the bank. Yes siree�� \n", nId );
		pMiner->ChangeLocation(bank);
	}

	return 0;
}

int	VisitBankAndDepositGold::Exit(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	printf("(%4d): Leavin' the bank\n", nId);
	return 0;
}

int	VisitBankAndDepositGold::Exec(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	//deposit the gold
	pMiner->AddToWealth(pMiner->GoldCarried());
	pMiner->SetGoldCarried(0);

	printf("(%4d): Depositing gold. Total savings now: %d \n", nId, pMiner->Wealth() );


	//wealthy enough to have a well earned rest?
	if (pMiner->Wealth() >= ComfortLevel)
	{
		printf("(%4d): WooHoo! Rich enough for now. Back home to mah li'lle lady\n", nId);

		_Tmessage pMessage(NULL, NULL, "GoHome");
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
		return 0;
	}

	//otherwise get more gold
	else 
	{
		_Tmessage pMessage(NULL, NULL, "EnterMine");
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
	}

	return 0;
}


////////////////////////////////////////////////////////////////////////////////

int	GoHomeAndSleepTilRested::Enter(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;


	if (pMiner->Location() != shack)
	{
		printf("(%4d): Walkin' home\n", nId);
		pMiner->ChangeLocation(shack);
		return 0;
	}

	return 0;
}

int	GoHomeAndSleepTilRested::Exit(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	printf("(%4d): Exit to Home\n", nId);
	return 0;
}

int	GoHomeAndSleepTilRested::Exec(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	if (!pMiner->Fatigued())
	{
		printf("(%4d): All mah fatigue has drained away. Time to find more gold! \n", nId);

		_Tmessage pMessage(NULL, NULL, "EnterMine");
		pEntity->m_pFSM->OnMessage("Change State", &pMessage);
	}

	else 
	{
		//sleep
		pMiner->DecreaseFatigue();
		printf("(%4d): ZZZZ...  \n", nId);
	} 


	return 0;
}


int	QuenchTirst::Enter(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	if (pMiner->Location() != saloon)
	{    
		pMiner->ChangeLocation(saloon);
		printf("(%4d): Boy, ah sure is thusty! Walking to the saloon \n", nId);
	}

	return 0;
}

int	QuenchTirst::Exit(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;


	printf("(%4d):Leaving the saloon, feelin' good \n", nId);
	return 0;
}

int	QuenchTirst::Exec(_Tentity* pEntity)
{
	int nId	= pEntity->GetID();
	Miner* pMiner	= (Miner*)pEntity;

	pMiner->BuyAndDrinkAWhiskey();
	printf("(%4d): That's mighty fine sippin' liquer \n", pEntity->GetID(), pEntity->m_iMp);

	_Tmessage pMessage(NULL, NULL, "EnterMine");
	pEntity->m_pFSM->OnMessage("Change State", &pMessage);

	return 0;
}


////////////////////////////////////////////////////////////////////////////////


void Miner::AddToGoldCarried(const int val)
{
  m_iGoldCarried += val;

  if (m_iGoldCarried < 0) m_iGoldCarried = 0;
}

void Miner::AddToWealth(const int val)
{
  m_iMoneyInBank += val;

  if (m_iMoneyInBank < 0) m_iMoneyInBank = 0;
}

bool Miner::Thirsty()const
{
  if (m_iThirst >= ThirstLevel){return true;}

  return false;
}

bool Miner::Fatigued()const
{
  if (m_iFatigue > TirednessThreshold)
  {
    return true;
  }

  return false;
}