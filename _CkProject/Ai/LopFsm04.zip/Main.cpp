

#include <windows.h> 
#include <stdio.h>

#include "State.h"
#include "StateMachine.h"

void main()
{
	if(FAILED(Lop_StateListCreate()))
		return;

	Miner*	pEntity = new Miner;

	pEntity->SetID(10);
	pEntity->Query("Set Stamina", (void*)5);
	pEntity->m_pFSM	= new CStateMachine;
	pEntity->m_pFSM->Create(pEntity);

	while(1)
	{
		Sleep(1000);

		pEntity->m_iThirst += 1;
  
		

		if(FAILED(pEntity->m_pFSM->Update()))
			break;
	}

	delete pEntity->m_pFSM;
	delete pEntity;


	Lop_StateListDestroy();
}