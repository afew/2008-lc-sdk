// StateMachine.h: interface for the CStateMachine class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _StateMachine_H_
#define _StateMachine_H_


class CStateMachine
{
protected:
	_Tentity*	m_pEntity;

	_Tstate*	m_pStCur;	// Current State
	_Tstate*	m_pStOld;	// Old State
	_Tstate*	m_pStInt;	// Interrupt State

public:
	CStateMachine();
	virtual ~CStateMachine();

	int			Create(_Tentity* pEntity);
	int			Update();

	int			OnMessage(char* sMsg, _Tmessage* pMessage);

	_Tstate*	GetStateOld();
};


#endif



