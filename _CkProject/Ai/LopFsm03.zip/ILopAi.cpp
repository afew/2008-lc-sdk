// Implementation of the ILopAi class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILopAi.h"
#include "LopSoul.h"


_TLopState::_TLopState()
{
	memset(sState, 0, sizeof sState);
	memset(sValue, 0, sizeof sValue);

	pExtra	= NULL;
}


_TLopState::_TLopState(void* _pOwner, char* _sState, char* _sValue, int _nValueSize, void* _pData)
{
	if(_pOwner)
		pOwner = _pOwner;

	memset(sState, 0, sizeof sState);
	memset(sValue, 0, sizeof sValue);

	strcpy(sState, _sState);
	memcpy(sState, &_nValueSize, sizeof(INT));
	memcpy(sState+10, _sValue, _nValueSize);

	pExtra	= _pData;
}


void _TLopState::SetState(void* _pOwner, char* _sState, char* _sValue, int _nValueSize, void* _pData)
{
	if(_pOwner)
		pOwner = _pOwner;

	if(_sState)
	{
		memset(sState, 0, sizeof sState);
		strcpy(sState, _sState);
	}

	if(_sValue)
	{
		memset(sValue, 0, sizeof sValue);
		memcpy(sState, &_nValueSize, sizeof(INT));
		memcpy(sState+10, _sValue, _nValueSize);
	}

	pExtra = _pData;
}


INT LcopST_CreateSoul(char* sCmd
				 , ILopAi** pExtra
				 , void* p1			// CGameData::TcharMate*
				 , void* p2			// No Use
				 , void* p3			// No Use
				 , void* p4			// No Use
				 )
{
	CLopSoul*	p = new CLopSoul;

	p->SetSoul(p1);

	*pExtra = p;

	return 0;
}