// Interface for the ILopBody.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILopBody_H_
#define _ILopBody_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface ILopBody
{
	LC_CLASS_DESTROYER(	ILopBody	);

	virtual	INT		FrameMove()=0;
	virtual	INT		Render()=0;
};


INT LcopST_CreateBody(char* sCmd
				 , ILopBody** pData
				 , void* p1			// CGameData::TcharMate*
				 , void* p2=0		// No Use
				 , void* p3=0		// No Use
				 , void* p4=0		// No Use
				 );


#endif

