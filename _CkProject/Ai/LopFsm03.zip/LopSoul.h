// Interface for the CLopSoul.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LopSoul_H_
#define _LopSoul_H_


class CLopSoul : public ILopAi
{
protected:
	_TLopState*		m_pStOld;		// Old State
	_TLopState*		m_pStCur;		// Current state
	_TLopState*		m_pStInt;		// Interrupt State

public:
	CLopSoul();
	virtual ~CLopSoul();

	virtual	INT		SetStateCur(_TLopState* sState);
	virtual	INT		SetStateOld(_TLopState* sState);
	virtual	INT		SetStateInt(_TLopState* sState);

	virtual	INT		GetStateCur(_TLopState** sState);
	virtual	INT		GetStateOld(_TLopState** sState);
	virtual	INT		GetStateInt(_TLopState** sState);

	virtual	INT		CompareCurState(char* sState);

	virtual	INT		SetSoul(void* p);

	virtual	INT		Update();
};

#endif

