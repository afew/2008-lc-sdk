// Implementation of the TocAmun class.
//
////////////////////////////////////////////////////////////////////////////////

#pragma warning(disable: 4786)

#include <windows.h>
#include <stdio.h>
#include <memory.h>
#include <d3dx9.h>

#include "ILopAi.h"
#include "ocAmun.h"


TocAmun::TocAmun()
{
	memset(m_AmName, 0, sizeof m_AmName);

	m_AmKaBa	= -1;
	m_AmActv	= ILopAi::STATE_ENABLE;
	m_AmMdl		= NULL;

	m_AmSt		= ILopAi::OCST_NONE;

	m_Thp		= 0;
	m_Tmp		= 0;
	m_Tst		= 0;
	m_TstH		= 0;

	memset(m_Mspd, 0, sizeof m_Mspd);
	memset(m_Mpos, 0, sizeof m_Mpos);
	memset(m_Mdir, 0, sizeof m_Mdir);
	memset(m_Mtgt, 0, sizeof m_Mtgt);
}


TocAmun::~TocAmun()
{
	Destroy();
}


INT TocAmun::Create(void* p1,void* p2,void* p3,void* p4)
{
	if(FAILED(_Tentity::Create(p1, p2, p3, p4)))
		return -1;


	ILopAi::_TstateFSM* pFSM	= new ILopAi::_TstateFSM;

	pFSM->Create(this);
	m_pFSM = pFSM;

	return 0;
}


void TocAmun::Destroy()
{
	if(m_pFSM)
	{
		ILopAi::_TstateFSM* pFSM	= (ILopAi::_TstateFSM*)m_pFSM;
		delete pFSM;
		m_pFSM = NULL;
	}
}


INT TocAmun::Update()
{
	ILopAi::_TstateFSM*	pFSM = (ILopAi::_TstateFSM*)m_pFSM;

	if(pFSM)
	{
		if(FAILED(pFSM->Update()))
			return -1;
	}
	
	return 0;
}


INT TocAmun::QueryState(char* sCmd, void* pData)
{
	INT nId	= this->GetID();
	ILopAi::_TstateFSM*	pFSM = (ILopAi::_TstateFSM*)m_pFSM;



	if(0 ==_stricmp(sCmd, "Enter Attack"))
	{
		printf("(%4d): Enter Attack \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exit Attack"))
	{
		printf("(%4d): Exit Attack \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exec Attack"))
	{
		printf("(%4d): Exec Attack \n", nId );
		return 0;
	}


	if(0 ==_stricmp(sCmd, "Enter Damage"))
	{
		printf("(%4d): Enter Damage \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exit Damage"))
	{
		printf("(%4d): Exit Damage \n", nId );
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Exec Damage"))
	{
		printf("(%4d): Exec Damage \n", nId );
		return 0;
	}



	// Idle
	else if(0 ==_stricmp(sCmd, "Enter Idle"))
	{
		m_AmSt	= ILopAi::OCST_IDLE;
		printf("(%4d): ��Enter Idle��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit Idle"))
	{
		printf("(%4d): ��Exit Idle��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Idle"))
	{
		printf("(%4d): ��Exec Idle��\n", nId );
		return 0;
	}


	// Walk
	else if(0 ==_stricmp(sCmd, "Enter walk"))
	{
		m_AmSt	= ILopAi::OCST_WALK;

		if(pData)
		{
			ILopAi::_Tmessage* pMessage	= (ILopAi::_Tmessage*)pData;

			INT	nSize = 0;
			D3DXVECTOR3	vcT;
			pMessage->GetText(&nSize, &vcT);

			if(nSize)
				m_Mtgt = vcT;
		}
		printf("(%4d): ��Enter walk��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit walk"))
	{
		printf("(%4d): ��Exit walk��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec walk"))
	{
		D3DXVECTOR3	vcT = m_Mtgt - m_Mpos;
		float		fL	= D3DXVec3LengthSq(&vcT);

		if(fL< m_Mspd[0] * m_Mspd[0] )
		{
			ILopAi::_Tmessage pMessage("Idle", NULL);
			this->OnMessage("Change State", &pMessage);
			return 0;
		}

		D3DXVec3Normalize(&m_Mdir, &vcT);

		m_Mpos[0] += m_Mspd[0] * m_Mdir[0];
		m_Mpos[1] += m_Mspd[0] * m_Mdir[1];
		m_Mpos[2] += m_Mspd[0] * m_Mdir[2];

		++m_Tst;

		if(m_Tst>m_TstH && fL>= m_Mspd[1] * m_Mspd[1]*1.4f)
		{
			ILopAi::_Tstate*	pStOld = pFSM->GetStateOld();
			ILopAi::_Tmessage*	pMessage = (ILopAi::_Tmessage*)pStOld->GetPhase();

			if(ILopAi::CMD_LOOP == pMessage->GetType() &&
				0 == _stricmp(pMessage->Phase, "Run"))
			{
				ILopAi::_Tmessage pMessage("Run", NULL);
				this->OnMessage("Change State", &pMessage);
				return 0;
			}
		}

		printf("(%4d): ��Exec walk(%f %f %f)��\n", nId,  m_Mpos[0], m_Mpos[1], m_Mpos[2]);
		return 0;
	}


	// Run
	else if(0 ==_stricmp(sCmd, "Enter Run"))
	{
		m_AmSt	= ILopAi::OCST_RUN;
		printf("(%4d): ��Enter Run��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit Run"))
	{
		printf("(%4d): ��Exit Run��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Run"))
	{
		D3DXVECTOR3	vcT = m_Mtgt - m_Mpos;
		float		fL	= D3DXVec3LengthSq(&vcT);

		if(fL< m_Mspd[1] * m_Mspd[1]*1.4f)
		{
			ILopAi::_Tmessage pMessage("Walk", NULL);
			this->OnMessage("Change State", &pMessage);
			return 0;
		}

		D3DXVec3Normalize(&m_Mdir, &vcT);

		m_Mpos[0] += m_Mspd[1] * m_Mdir[0];
		m_Mpos[1] += m_Mspd[1] * m_Mdir[1];
		m_Mpos[2] += m_Mspd[1] * m_Mdir[2];

		--m_Tst;

		if(m_Tst<1)
		{
			ILopAi::_Tmessage pMessage("Walk", NULL);
			this->OnMessage("Change State", &pMessage);
			return 0;
		}
		printf("(%4d): ��Exec Run(%f %f %f)��\n", nId,  m_Mpos[0], m_Mpos[1], m_Mpos[2]);
		return 0;
	}


	// Dash
	else if(0 ==_stricmp(sCmd, "Enter Dash"))
	{
		m_AmSt	= ILopAi::OCST_DASH;
		printf("(%4d): ��Enter Dash��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exit Dash"))
	{
		printf("(%4d): ��Exit Dash��\n", nId );
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Exec Dash"))
	{
		m_Mpos[0] += m_Mspd[2] * m_Mdir[0];
		m_Mpos[1] += m_Mspd[2] * m_Mdir[1];
		m_Mpos[2] += m_Mspd[2] * m_Mdir[2];

		printf("(%4d): ��Exec Dash��\n", nId );
		return 0;
	}

	else
	{
		if(FAILED(_Tentity::QueryState(sCmd, pData)))
			return -1;
	}

	return 0;
}



INT TocAmun::QueryValue(char* sCmd, void* pData)
{
	char		m_AmName[64];		// Character Name

	if(0 ==_stricmp(sCmd, "Set Name"))
	{
		strcpy(m_AmName, *((char**)pData));
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Name"))
	{
		strcpy(*((char**)pData), m_AmName);
		return 0;
	}

	
	else if(0 ==_stricmp(sCmd, "Set KaBa"))
	{
		m_AmKaBa = *((INT*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get KaBa"))
	{
		*((INT*)pData)	= m_AmKaBa;
		return 0;
	}


	else if(0 ==_stricmp(sCmd, "Set Hp"))
	{
		m_Thp = *((INT*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Hp"))
	{
		*((INT*)pData)	= m_Thp;
		return 0;
	}


	else if(0 ==_stricmp(sCmd, "Set Mp"))
	{
		m_Tmp = *((INT*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Mp"))
	{
		*((INT*)pData)	= m_Tmp;
		return 0;
	}

	
	else if(0 ==_stricmp(sCmd, "Set Stamina"))
	{
		m_Tst = *((INT*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Stamina"))
	{
		*((INT*)pData)	= m_Tst;
		return 0;
	}

	else if(0 ==_stricmp(sCmd, "Set St Threshold"))
	{
		m_TstH = *((INT*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get St Threshold"))
	{
		*((INT*)pData) 	= m_TstH;
		return 0;
	}

	


	else if(0 ==_stricmp(sCmd, "Set Speed"))
	{
		m_Mspd = *((D3DXVECTOR3*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Speed"))
	{
		*((D3DXVECTOR3*)pData) = m_Mspd;
		return 0;
	}


	else if(0 ==_stricmp(sCmd, "Set Position"))
	{
		m_Mpos = *((D3DXVECTOR3*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Position"))
	{
		*((D3DXVECTOR3*)pData) = m_Mpos;
		return 0;
	}


	else if(0 ==_stricmp(sCmd, "Set Direction"))
	{
		m_Mdir = *((D3DXVECTOR3*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Direction"))
	{
		*((D3DXVECTOR3*)pData) = m_Mdir;
		return 0;
	}


	else if(0 ==_stricmp(sCmd, "Set Target"))
	{
		m_Mtgt = *((D3DXVECTOR3*)pData);
		return 0;
	}
	else if(0 ==_stricmp(sCmd, "Get Target"))
	{
		*((D3DXVECTOR3*)pData) = m_Mtgt;
		return 0;
	}

	else
	{
		if(FAILED(_Tentity::QueryValue(sCmd, pData)))
			return -1;
	}

	return 0;
}