

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "d3dx9.lib")

#include <windows.h>
#include <stdio.h>
#include <d3dx9.h>

#include "ILopAi.h"
#include "ocAmun.h"
#include "ocBoy.h"


void main()
{
	TocBoy*	pEnt1 = new TocBoy;
	TocBoy*	pEnt2 = new TocBoy;


//	pEnt1->Create((void*)10, (void*)1);
	pEnt2->Create((void*)20, (void*)3);


	INT Thp	= 10;
	INT Tmp	= 20;
	INT Tst	= 10;
	INT stThreshold	= 20;

	D3DXVECTOR3 vcS	= D3DXVECTOR3(2, 3, 6);
	D3DXVECTOR3 vcB	= D3DXVECTOR3(3, 1, 2);
	D3DXVECTOR3 vcE	= D3DXVECTOR3(140, 0, 0);
	D3DXVECTOR3 vcD	= vcE - vcB;
	D3DXVec3Normalize(&vcD, &vcD);

//	{
//		pEnt1->QueryValue("Set Speed", &vcS);
//		pEnt1->QueryValue("Set Position", &vcB);
//		pEnt1->QueryValue("Set Direction", &vcD);
//		pEnt1->QueryValue("Set Target", &vcE);
//
//		pEnt1->QueryValue("Set Hp", &Thp);
//		pEnt1->QueryValue("Set Mp", &Tmp);
//		pEnt1->QueryValue("Set Stamina", &Tst);
//		pEnt1->QueryValue("Set St Threshold", &stThreshold);
//		
//
//		ILopAi::_Tmessage pMessage(NULL, "Run");
//		pEnt1->OnMessage("Change State", &pMessage);
//	}

	{
		stThreshold	*=0.6f;
//		vcS	*= .5f;
//		vcE	*= .4f;
		vcD	= vcE - vcB;
		D3DXVec3Normalize(&vcD, &vcD);

		pEnt2->QueryValue("Set Speed", &vcS);
		pEnt2->QueryValue("Set Position", &vcB);
		pEnt2->QueryValue("Set Direction", &vcD);
		pEnt2->QueryValue("Set Target", &vcE);

		pEnt2->QueryValue("Set Hp", &Thp);
		pEnt2->QueryValue("Set Mp", &Tmp);
		pEnt2->QueryValue("Set Stamina", &Tst);
		pEnt2->QueryValue("Set St Threshold", &stThreshold);

		{
			ILopAi::_Tmessage pMessage("Attack", NULL, ILopAi::CMD_ONCE, NULL, 3000);
			pEnt2->OnMessage("Change State", &pMessage);
		}

		{
			ILopAi::_Tmessage pMessage("Damage", NULL, ILopAi::CMD_ONCE, NULL, 4000);
			pEnt2->OnMessage("Change State", &pMessage);
		}

		{
			ILopAi::_Tmessage pMessage("Run", NULL, ILopAi::CMD_LOOP, NULL, 5000);
			pEnt2->OnMessage("Change State", &pMessage);
		}
	}

	static INT c=0;


	while(1)
	{
		Sleep(500);

		if(++c>100)
			break;

//		pEnt1->Update();
		pEnt2->Update();
	}

	pEnt1->Destroy();
	delete pEnt1;


	pEnt2->Destroy();
	delete pEnt2;
}