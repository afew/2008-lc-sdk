// Interface for the CocAmun class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _TocAmun_H_
#define _TocAmun_H_


struct TocAmun : public ILopAi::_Tentity
{
	char			m_AmName[64];		// Character Name

	INT				m_AmKaBa;			// Man[0: Human, arc: 1], Woman[2: Human, Arc: 3]
	INT				m_AmActive;			// Activation
	void*			m_AmData;			// Model 3D Data

	ILopAi::EocState m_eSt;				// State

	INT				m_Thp;				// Hp
	INT				m_Tmp;				// Mana Point
	INT				m_Tst;				// Stamina
	INT				m_TstH;				// Stamina threshold

	D3DXVECTOR3		m_Mspd;				// Move Speed: 0 Walk, 1: Run 2: Dash
	D3DXVECTOR3		m_Mpos;				// Move Position
	D3DXVECTOR3		m_Mdir;				// Move Direction
	D3DXVECTOR3		m_Mtgt;				// Move Target

	TocAmun();
	virtual ~TocAmun();

	virtual	INT		Create(void* =0,void* =0,void* =0,void* =0);
	virtual	void	Destroy();
	virtual	INT		Update();
	virtual	INT		QueryState(char* sCmd, void* pData);
	virtual	INT		QueryValue(char* sCmd, void* pData);

	ILopAi::EocState	GetState()	const	{	return m_eSt;}
};

#endif


